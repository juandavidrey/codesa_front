package com.codesa.codesa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OdesaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdesaApplication.class, args);
	}

}
